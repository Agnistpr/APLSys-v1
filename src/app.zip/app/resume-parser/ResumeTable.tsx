import { Fragment } from "react";
import { initialEducation, initialWorkExperience } from "../lib/redux/resumeSlice";
import { deepClone } from "../lib/deep-clone";
import { cx } from "../lib/cx";

const TableRowHeader = ({ children }: { children: React.ReactNode }) => (
  <tr className="divide-x bg-gray-50">
    <th className="px-3 py-2 font-semibold text-gray-800" scope="colgroup" colSpan={2}>
      {children}
    </th>
  </tr>
);

interface TableRowProps {
  label: string;
  value: string | string[];
  fieldKey: string;
  onFieldChange?: (field: string, value: string) => void;
  className?: string | false;
}

const TableRow = ({ label, value, fieldKey, onFieldChange, className }: TableRowProps) => {
  const renderValue = () => {
    if (typeof value === "string") {
      return onFieldChange ? (
        <input
          type="text"
          value={value}
          onChange={(e) => onFieldChange(fieldKey, e.target.value)}
          className="border px-2 py-1 rounded w-full"
        />
      ) : (
        value
      );
    }

    // Handle array values (like descriptions)
    return onFieldChange ? (
      <textarea
        value={value.join("\n")}
        onChange={(e) => onFieldChange(fieldKey, e.target.value)}
        className="border px-2 py-1 rounded w-full"
        rows={Math.max(2, value.length)}
      />
    ) : (
      value.map((x, idx) => (
        <Fragment key={idx}>
          • {x}
          <br />
        </Fragment>
      ))
    );
  };

  return (
    <tr className={cx("divide-x", className)}>
      <th className="px-3 py-2 font-medium text-gray-700" scope="row">
        {label}
      </th>
      <td className="w-full px-3 py-2">{renderValue()}</td>
    </tr>
  );
};

export const ResumeTable = ({
  resume,
  onFieldChange,
}: {
  resume: Resume;
  onFieldChange?: (field: string, value: string) => void;
}) => {
  const educations = resume.educations.length ? resume.educations : [deepClone(initialEducation)];
  const workExperiences = resume.workExperiences.length
    ? resume.workExperiences
    : [deepClone(initialWorkExperience)];

  // Merge featured skills into descriptions
  const featuredSkills = resume.skills.featuredSkills
    .map((item) => item.skill.trim())
    .filter(Boolean);
  const skills = [...featuredSkills, ...resume.skills.descriptions];

  return (
    <table className="mt-2 w-full border text-sm text-gray-900">
      <tbody className="divide-y text-left align-top">
        {/* Profile */}
        <TableRowHeader>Profile</TableRowHeader>
        {[
          ["Name", resume.profile.name, "profile.name"],
          ["Age", resume.profile.age || "", "profile.age"],
          ["Gender", resume.profile.gender || "", "profile.gender"],
          ["Email", resume.profile.email, "profile.email"],
          ["Phone", resume.profile.phone, "profile.phone"],
          ["Location", resume.profile.location, "profile.location"],
          ["Link", resume.profile.url, "profile.url"],
          ["Summary", resume.profile.summary, "profile.summary"],
        ].map(([label, value, key]) => (
          <TableRow
            key={key as string}
            label={label as string}
            value={value as string}
            fieldKey={key as string}
            onFieldChange={onFieldChange}
          />
        ))}

        {/* Education */}
        <TableRowHeader>Education</TableRowHeader>
        {educations.map((edu, idx) => (
          <Fragment key={idx}>
            <TableRow label="School" value={edu.school} fieldKey={`educations.${idx}.school`} onFieldChange={onFieldChange} />
            <TableRow label="Degree" value={edu.degree} fieldKey={`educations.${idx}.degree`} onFieldChange={onFieldChange} />
            <TableRow label="GPA" value={edu.gpa} fieldKey={`educations.${idx}.gpa`} onFieldChange={onFieldChange} />
            <TableRow label="Date" value={edu.date} fieldKey={`educations.${idx}.date`} onFieldChange={onFieldChange} />
            <TableRow
              label="Descriptions"
              value={edu.descriptions}
              fieldKey={`educations.${idx}.descriptions`}
              onFieldChange={onFieldChange}
              className={idx < educations.length - 1 && "!border-b-4"}
            />
          </Fragment>
        ))}

        {/* Work Experience */}
        <TableRowHeader>Work Experience</TableRowHeader>
        {workExperiences.map((work, idx) => (
          <Fragment key={idx}>
            <TableRow label="Company" value={work.company} fieldKey={`workExperiences.${idx}.company`} onFieldChange={onFieldChange} />
            <TableRow label="Job Title" value={work.jobTitle} fieldKey={`workExperiences.${idx}.jobTitle`} onFieldChange={onFieldChange} />
            <TableRow label="Date" value={work.date} fieldKey={`workExperiences.${idx}.date`} onFieldChange={onFieldChange} />
            <TableRow
              label="Descriptions"
              value={work.descriptions}
              fieldKey={`workExperiences.${idx}.descriptions`}
              onFieldChange={onFieldChange}
              className={idx < workExperiences.length - 1 && "!border-b-4"}
            />
          </Fragment>
        ))}

        {/* Projects */}
        {resume.projects.length > 0 && <TableRowHeader>Projects</TableRowHeader>}
        {resume.projects.map((proj, idx) => (
          <Fragment key={idx}>
            <TableRow label="Project" value={proj.project} fieldKey={`projects.${idx}.project`} onFieldChange={onFieldChange} />
            <TableRow label="Date" value={proj.date} fieldKey={`projects.${idx}.date`} onFieldChange={onFieldChange} />
            <TableRow
              label="Descriptions"
              value={proj.descriptions}
              fieldKey={`projects.${idx}.descriptions`}
              onFieldChange={onFieldChange}
              className={idx < resume.projects.length - 1 && "!border-b-4"}
            />
          </Fragment>
        ))}

        {/* Skills */}
        <TableRowHeader>Skills</TableRowHeader>
        <TableRow label="Descriptions" value={skills} fieldKey="skills.descriptions" onFieldChange={onFieldChange} />
      </tbody>
    </table>
  );
};