import "public/fonts/fonts-zh.css";

/**
 * Empty component. Main purpose is to load fonts-zh.css
 */
const FontsZh = () => <></>;
export default FontsZh;